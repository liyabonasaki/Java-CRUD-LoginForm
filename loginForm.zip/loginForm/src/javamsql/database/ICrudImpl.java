/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javamsql.database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javamsql.model.user;

/**
 *
 * @author Liyabona Saki
 */
public class ICrudImpl implements ICrud {
    
    private Connection  conn;

    @Override
    public boolean insert(user use) {
        
        Statement statement ;
        try {
            String query = "INSERT INTO users VALUES ('"+use.getName()+"','"+use.getLastname()+"','"+use.getUsername()+"','"+use.getPassword()+"','"+use.getConfirmPassword()+"')";
            statement = this.conn.createStatement();  
            statement.executeUpdate(query); 
            statement.close();
            return true;
          
            
        } catch (SQLException ex) {
          System.out.println("Sorry something went wrong");
            return false;
        } 
        
    }

    @Override
    public user getUser(String username, String password) {
      
         
        try {
            Statement statement ;
            String query = "SELECT * FROM `users` WHERE `username`"+ username+" AND `password`"+ password + "'";
          
            ResultSet rs;
            user us;
            try (PreparedStatement ps = this.conn.prepareStatement(query)) {
                rs = ps.executeQuery(query);
                us = null;
                if (rs.next()){
                    
                    us = new user();
                    us.setName(rs.getString("name"));
                    us.setLastname(rs.getString("lastname"));
                    us.setUsername(rs.getString("username"));
                    us.setPassword(rs.getString("password"));
                    us.setConfirmPassword(rs.getString("confirmPassword"));
                }}
           rs.close();
           
           
            return us;
            
        } catch (SQLException ex) {
            return null;
        } 
    }
    
    
    
    
    public void openConnection(){
        
        try{
            
          Class.forName("com.mysql.cj.jdbc.Driver");
             this.conn = DriverManager.getConnection("jdbc:mysql://localhost/login","root", "");
             System.out.println("Connection established successfully with the database server");
            
        }catch(ClassNotFoundException | SQLException e){
            System.err.println("Error :" + e.getMessage());
            
        }
        
    }

   
    
}
