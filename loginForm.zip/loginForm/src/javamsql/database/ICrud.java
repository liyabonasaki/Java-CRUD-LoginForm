/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javamsql.database;

import javamsql.model.user;

/**
 *
 * @author Liyabona Saki
 */
public interface ICrud {
    
    boolean insert(user  use);
    
    user getUser(String username , String password);
    
}
