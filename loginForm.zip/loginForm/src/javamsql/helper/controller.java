/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javamsql.helper;

import javamsql.database.ICrudImpl;
import javamsql.model.user;

/**
 *
 * @author Liyabona Saki
 */
public class controller {
    
    
    private static controller con;
    private final ICrudImpl ICrudImpl;
        
        private controller(){
            
            this.ICrudImpl = new ICrudImpl();
            this.ICrudImpl.openConnection();
        }
        
        public static controller getcontroller(){
            
            if(con == null){
                
                con = new controller();    
            }
        return con;
            
            
        }

    public boolean signup(user use) {
        
        return this.ICrudImpl.insert(use);
    }

    public user login(String username, String password) {
      return this.ICrudImpl.getUser(username, password);
        
    }
    
    
}
